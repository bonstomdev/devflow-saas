# DevFlow SaaS 🚀

Modern SaaS-style project management dashboard for Software Engineers.

## Stack
Next.js · React · TypeScript · TailwindCSS-ready · Responsive UI

## Features
- Developer dashboard
- Kanban sprint board
- Project/task statistics
- Responsive design
- SaaS-style UI
- Clean architecture ready for backend integrations

## Run
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

## Roadmap
- [ ] Supabase Auth + PostgreSQL
- [ ] Task CRUD
- [ ] Team workspaces
- [ ] OpenAI assistant
- [ ] Stripe subscriptions
- [ ] Resend email
- [ ] Sentry monitoring
- [ ] Docker
- [ ] GitHub Actions CI
- [ ] Vercel deployment

## License
MIT
